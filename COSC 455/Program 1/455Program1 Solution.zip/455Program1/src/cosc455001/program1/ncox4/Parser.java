/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc455001.program1.ncox4;

/*
COURSE: COSC455001
Name: Cox, Nathan
*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The Syntax Analyzer *
 */
class Parser {
    // The lexer which will provide the tokens

    private final LexicalAnalyzer lexer;
    private final CodeGenerator codeGenerator;

    /**
     * The constructor initializes the terminal literals in their vectors.
     *
     * @param lexer The Lexer Object
     */
    public Parser(LexicalAnalyzer lexer, CodeGenerator codeGenerator) {
        this.lexer = lexer;
        this.codeGenerator = codeGenerator;
    }

    /**
     * Begin analyzing...
     *
     * @throws MockCompiler.ParseException
     */
    public void analyze() {
        try {
            // Generate header for our output
            ParseNode startNode = codeGenerator.buildNode("PARSE TREE");
            codeGenerator.writeHeader(startNode);

            // Start the actual parsing.   
            Expression(startNode);

            // generate footer for our output
            codeGenerator.writeFooter();

            // For graphically displaying the output.
            // CodeGenerator.openWebGraphViz();
        } catch (ParseException ex) {
            System.err.println("Syntax Error: " + ex);
        }
    }

        //<PROGRAM> ::= <STMT_LIST> $$ 
    protected void Expression(ParseNode fromNode) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<Expression>");
        codeGenerator.addNonTerminalToTree(fromNode, nodeName);
        stmt_list(nodeName);
    }

    //<stmt_list> ::= <stmt> <stmt_list> | <EMPTY> 
    protected void stmt_list(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<STATEMENT LIST>");
        codeGenerator.addNonTerminalToTree(from, nodeName);
        stmt(nodeName);
    }

    //<stmt> ::= <ID> <ASSIGN> <expr> | <READ> <ID> | <WRITE> <expr> | <IF> <cond> <THEN> <stmt_list> <FI>
    void stmt(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<STATEMENT>");
        codeGenerator.addNonTerminalToTree(from, nodeName);

        if (lexer.isCurrentToken(TOKEN.ID)) {
            ID(nodeName);
            ASSIGN(nodeName);
            expr(nodeName);
            stmt_tail(nodeName);
        } else {
            if (lexer.isCurrentToken(TOKEN.READ)) {
                READ(nodeName);
                ID(nodeName);
                stmt_tail(nodeName);
            } else {
                if (lexer.isCurrentToken(TOKEN.WRITE)) {
                    WRITE(nodeName);
                    expr(nodeName);
                    stmt_tail(nodeName);
                } else {
                    if (lexer.isCurrentToken(TOKEN.IF)) {
                        IF(nodeName);
                        condition(nodeName);
                        THEN(nodeName);
                        stmt_list(nodeName);
                        FI(nodeName);
                        stmt_tail(nodeName);
                    } else {
                        if (lexer.isCurrentToken(TOKEN.WHILE)) {
                            WHILE(nodeName);
                            condition(nodeName);
                            DO(nodeName);
                            stmt_list(nodeName);
                            OD(nodeName);
                            stmt_tail(nodeName);
                        }
                    }
                }
            }
        }
    }

    //<stmt_tail> ::= <stmt>
    void stmt_tail(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<STATEMENT_TAIL>");
        codeGenerator.addNonTerminalToTree(from, nodeName);

        stmt(nodeName);
    }

    //<cond> ::= <expr> <RELATION> <expr>
    void condition(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<CONDITION>");
        codeGenerator.addNonTerminalToTree(from, nodeName);

        expr(nodeName);
        RELATION(nodeName);
        expr(nodeName);
    }

    // <expr> ::= <term> <expr_tail> | <<EMPTY>>
    void expr(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<EXPR>");
        codeGenerator.addNonTerminalToTree(from, nodeName);

        term(nodeName);
        expr_tail(nodeName);
    }

    // <expr_tail> ::= <ADD_OP> <expr> | <<EMPTY>>
    void expr_tail(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<EXPR_TAIL>");

        if (lexer.isCurrentToken(TOKEN.ADD_OP)) {
            codeGenerator.addNonTerminalToTree(from, nodeName);
            ADD_OP(nodeName);
            expr(nodeName);
        }
    }

    // <term> ::= <factor> <term_tail>
    void term(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<TERM>");
        codeGenerator.addNonTerminalToTree(from, nodeName);

        factor(nodeName);
        term_tail(nodeName);
    }

    // <term_tail> ::= <MULT_OP> <term> | <empty>
    void term_tail(ParseNode from) throws ParseException {

        if (lexer.isCurrentToken(TOKEN.MULT_OP)) {
            final ParseNode nodeName = codeGenerator.buildNode("<TERM_TAIL>");
            codeGenerator.addNonTerminalToTree(from, nodeName);
            MULT_OP(nodeName);
            term(nodeName);
        }
    }

    // <factor> ::= <LPARENTHESIS> <expr> <RPARENTHESIS> | <ID>
    void factor(ParseNode from) throws ParseException {
        final ParseNode nodeName = codeGenerator.buildNode("<FACTOR>");
        codeGenerator.addNonTerminalToTree(from, nodeName);

        if (lexer.isCurrentToken(TOKEN.LPAREN)) {
            LPAREN(nodeName);
            expr(nodeName);
            RPAREN(nodeName);
        } else {
            ID(nodeName);
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////
    // For the sake of completeness, each terminal-token has it's own method,
    // though they all do the same thing here.  In a "REAL" Expression, each terminal
    // would likely have unique code associated with it.
    /////////////////////////////////////////////////////////////////////////////////////
    // <EOS>
    void READ(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.READ, fromNode);
    }

    // <ADJ>
    void WRITE(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.WRITE, fromNode);
    }

    // <ADV> 
    void IF(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.IF, fromNode);
    }

    // <ART> 
    void THEN(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.THEN, fromNode);
    }

    // <CONJ> 
    void FI(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.FI, fromNode);
    }

    // <NOUN>
    void LPAREN(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.LPAREN, fromNode);
    }

    // <PREP>
    void RPAREN(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.RPAREN, fromNode);
    }

    // <VERB>
    void ASSIGN(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.ASSIGN, fromNode);
    }

    // <ADJ_SEP>
    void ADD_OP(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.ADD_OP, fromNode);
    }

    void MULT_OP(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.MULT_OP, fromNode);
    }

    void RELATION(ParseNode from) throws ParseException {
        ProcessTerminal(TOKEN.RELATION, from);
    }

    void ID(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.ID, fromNode);
    }

    void EOS(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.EOS, fromNode);
    }

    void WHILE(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.WHILE, fromNode);
    }

    void DO(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.DO, fromNode);
    }

    void OD(ParseNode fromNode) throws ParseException {
        ProcessTerminal(TOKEN.OD, fromNode);
    }
    

    

    ////////////////////////////////////////////////////////////////////////////
    // Terminal:
    // Test it's type and continute if we really have a terminal node, syntax error if fails.
    void ProcessTerminal(TOKEN terminal, ParseNode fromNode) throws ParseException {
        final ParseNode terminalID = codeGenerator.buildNode(String.format("<%s>", terminal));

        if (!lexer.isCurrentToken(terminal)) {
            raiseException(terminal, fromNode);
        } else {
            codeGenerator.addNonTerminalToTree(fromNode, terminalID);
            codeGenerator.addTerminalToTree(terminalID, lexer.getLexeme());
            lexer.advanceToken();
        }
    }

    // The code below this point is just a bunch of "helper functions" to keep the
    // parser code (above) a bit cleaner.
    // Handle all of the errors in one place for cleaner parser code.
    private void raiseException(TOKEN expected, ParseNode fromNode) throws ParseException {
        final String template = "SYNTAX ERROR: '%s' was expected but '%s' was found.";
        String err = String.format(template, expected.toString(), lexer.getLexeme());

        codeGenerator.syntaxError(err, fromNode);
    }

    static class ParseException extends Exception {

        public ParseException(String errMsg) {
            super(errMsg);
        }
    }
}

/**
 * All Of the Tokens/Terminals Used by the parser
 */
/**
 * All Of the Tokens Used by the parser *
 */
enum TOKEN {
    READ("read"), WRITE("write"), IF("if"), THEN("then"), FI("fi"), LPAREN("("),
    WHILE("while"), DO("do"), OD("od"),
    RPAREN(")"), ASSIGN(":="), ADD_OP("+", "-"),
    MULT_OP("*", "/"), RELATION("<", ">", "<=", ">=", "=", "!="), ID, EOF, EOS("$$"),
    OTHER;
    
    private final List<String> lexemeList;

    private TOKEN(String... tokenStrings) {
        lexemeList = new ArrayList<>(tokenStrings.length);
        lexemeList.addAll(Arrays.asList(tokenStrings));
    }

    public static TOKEN fromLexeme(final String string) {
        // Just to be safe...
        String lexeme = string.trim();

        // An empty string should mean no more tokens to process.
        if (lexeme.isEmpty()) {
            return EOF;
        }

        // Search through ALL lexemes looking for a match with early bailout.
        for (TOKEN t : TOKEN.values()) {
            if (t.lexemeList.contains(lexeme)) {
                // early bailout.
                return t;
            }
        }

        return OTHER;
    }
}